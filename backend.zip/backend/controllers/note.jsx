//Contains the functions that handle incoming requests and provide responses (for API endpoints).
//Helps separate concerns by moving logic out of the routes and into the controller functions.